package com.example.Splendour;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ProductAdapter extends BaseAdapter {

    private ArrayList<Product> productdata;
    private LayoutInflater inflater;

    public ProductAdapter(Context context,ArrayList<Product> productdata){
        this.productdata = productdata;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return productdata.size();
    }

    @Override
    public Object getItem(int i) {
        return productdata.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;

        if (view == null){
            view = inflater.inflate(R.layout.product_row,null);
            viewHolder = new ViewHolder();
            viewHolder.imgtv = view.findViewById(R.id.tvimg);
            viewHolder.desctv = view.findViewById(R.id.tvdesc);
            viewHolder.pritv = view.findViewById(R.id.tvpri);

        }
        else
            viewHolder = (ViewHolder) view.getTag();
        viewHolder.imgtv.setImageResource(productdata.get(i).getImgprod());
        viewHolder.desctv.setText(productdata.get(i).getDesc());
        viewHolder.pritv.setText(String.valueOf(productdata.get(i).getPri()));
        return view;
    }

    static  class ViewHolder{
        private ImageView imgtv;
        private TextView desctv;
        private TextView pritv;
    }
}
