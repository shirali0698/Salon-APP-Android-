package com.example.Splendour;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class hmcontactus extends AppCompatActivity {
    ImageView home;
    TextView hm,gm,cc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hmcontactus);

        home =findViewById(R.id.imageButton);
        hm =findViewById(R.id.tvhmore);
        gm =findViewById(R.id.tvgmore);
        cc =findViewById(R.id.tvccmore);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HairmasterHome.class);

                startActivity(intent);
            }
        });
        hm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HairMaster.class);

                startActivity(intent);
            }
        });
        gm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Glamarous.class);

                startActivity(intent);
            }
        });
        cc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Cutscurves.class);

                startActivity(intent);
            }
        });
    }
}