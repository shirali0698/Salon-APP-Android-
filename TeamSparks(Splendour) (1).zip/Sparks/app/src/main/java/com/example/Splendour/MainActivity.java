package com.example.Splendour;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity  {
    private ViewPager mslideviewPager;
    private LinearLayout mdotslayout;

    private TextView[] mDots;

    private SlideAdapter slideAdapter;

    private Button mnextBtn, mpreviosBtn, mfinishBtn;
    private int mcurentPage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mslideviewPager = findViewById(R.id.sideViewPager);
        mdotslayout = findViewById(R.id.dotslayout);
        mnextBtn = findViewById(R.id.nextBtn);
        mpreviosBtn = findViewById(R.id.prevBtn);

        slideAdapter = new SlideAdapter(this);
        mslideviewPager.setAdapter(slideAdapter);
        mfinishBtn = findViewById(R.id.finishBtn);


        addDotsIndicator(0);

        mslideviewPager.addOnPageChangeListener(viewListener);

        mnextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mslideviewPager.setCurrentItem(mcurentPage + 1);

            }
        });

        mpreviosBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mslideviewPager.setCurrentItem(mcurentPage - 1);
            }
        });

        mfinishBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),Register.class));
            }
        });




    }
    public void addDotsIndicator(int position){
        mDots = new TextView[4];

        for (int i = 0 ; i<mDots.length; i++){

            mDots[i] = new TextView(this);
            mDots[i].setText(Html.fromHtml("&#8226;"));
            mDots[i].setTextSize(35);
            mDots[i].setTextColor(getResources().getColor(R.color.colortransperentWhite));

            mdotslayout.addView(mDots[i]);
        }

        if (mDots.length > 0){
            mDots[position].setTextColor(getResources().getColor(R.color.colorWhite));
        }
    }

    ViewPager.OnPageChangeListener viewListener = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {
            addDotsIndicator(position);

            mcurentPage = position;

            if(position == 0){
                mnextBtn.setEnabled(true);
                mpreviosBtn.setEnabled(false);
                mfinishBtn.setEnabled(false);
                mpreviosBtn.setVisibility(View.INVISIBLE);
                mfinishBtn.setVisibility(View.INVISIBLE);

            }
            else if (position == mDots.length - 1){
                mnextBtn.setEnabled(false);
                mfinishBtn.setEnabled(true);
                mpreviosBtn.setEnabled(true);
                mpreviosBtn.setVisibility(View.VISIBLE);
                mfinishBtn.setVisibility(View.VISIBLE);
                mnextBtn.setVisibility(View.INVISIBLE);

                mnextBtn.setBackground(null);
                mfinishBtn.setText("Finish");

            }
            else {
                mnextBtn.setEnabled(true);
                mpreviosBtn.setEnabled(true);
                mfinishBtn.setEnabled(false);
                mpreviosBtn.setVisibility(View.VISIBLE);
                mfinishBtn.setVisibility(View.INVISIBLE);

            }
        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    };

}
