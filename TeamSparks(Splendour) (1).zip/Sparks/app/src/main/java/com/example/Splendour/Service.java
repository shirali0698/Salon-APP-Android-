package com.example.Splendour;

public class Service {
    String category;
    String service;
    int price;

    public Service(String category, String service, int price) {
        this.category = category;
        this.service = service;
        this.price = price;
    }

    public String getCategory() {
        return category;
    }

    public String getService() {
        return service;
    }

    public int getPrice() {
        return price;
    }
}
