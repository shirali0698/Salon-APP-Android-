package com.example.Splendour;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class SelectSalon extends AppCompatActivity {
    TextView titlecat,t1,t2,t3;
    EditText ser,pr;
    CheckBox c1,c2,c3;
    Button con,back4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_salon);

        ser =findViewById(R.id.txt_ser);
        titlecat = findViewById(R.id.tvcname);
        pr = findViewById(R.id.txt_pr);
        c1 = findViewById(R.id.checkBox2);
        c2 = findViewById(R.id.checkBox3);
        c3 = findViewById(R.id.checkBox4);

        t1 = findViewById(R.id.textView17);
        t2 = findViewById(R.id.textView18);
        t3 = findViewById(R.id.textView19);
        back4 = findViewById(R.id.btnback4);
        back4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(getApplicationContext(),Services.class);
                startActivity(intent);
            }
        });

        titlecat.setText(Services.title);
        ser.setText(Services.se);
        pr.setText(String.valueOf(Services.p));
        con = findViewById(R.id.btncon);
        con.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                con.setVisibility(View.INVISIBLE);
                titlecat.setVisibility(View.INVISIBLE);
                ser.setVisibility(View.INVISIBLE);
                pr.setVisibility(View.INVISIBLE);
                t1.setVisibility(View.INVISIBLE);
                t2.setVisibility(View.INVISIBLE);
                t3.setVisibility(View.INVISIBLE);
                c1.setVisibility(View.INVISIBLE);
                c2.setVisibility(View.INVISIBLE);
                c3.setVisibility(View.INVISIBLE);
                FragmentManager fm = getSupportFragmentManager();
                BookingFragment bookingFragment = new BookingFragment();
                fm.beginTransaction().replace(R.id.container,bookingFragment).commit();
            }
        });

    }
}