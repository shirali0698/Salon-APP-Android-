package com.example.Splendour;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class ListAdapter extends BaseAdapter {
    private ArrayList<Service> servicedata;
    private LayoutInflater layoutInflater;

    public ListAdapter(Context context, ArrayList<Service> servicedata) {
        this.servicedata = servicedata;
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return servicedata.size();
    }

    @Override
    public Object getItem(int i) {
        return servicedata.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
       ViewHolder holder;

       if(view == null){
           view = layoutInflater.inflate(R.layout.list_row,null);
           holder = new ViewHolder();
           holder.servicetv = view.findViewById(R.id.tvservice);
           holder.pricetv = view.findViewById(R.id.tvprice);
       }
       else
           holder = (ViewHolder) view.getTag();
       holder.servicetv.setText(servicedata.get(i).getService());
       holder.pricetv.setText(String.valueOf(servicedata.get(i).getPrice()));

        return view;
    }

    static class ViewHolder{
        private TextView servicetv;
        private TextView pricetv;
    }
}
