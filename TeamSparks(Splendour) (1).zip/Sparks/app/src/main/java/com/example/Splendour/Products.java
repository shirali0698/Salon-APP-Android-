package com.example.Splendour;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

public class Products extends AppCompatActivity implements AdapterView.OnItemSelectedListener, AdapterView.OnItemClickListener {
    Spinner spinner;
    ListView listView;
    Button back3;

    ArrayList<Product> prod = new ArrayList<Product>();
    String prods[] = {"LIPSTICK","EYELINER","EYESHADOW","NAIL POLISH","HAIRCLIPS", "TIARA", "SKIN CARE", "HAIR CARE"};

    ArrayList<Product> selectedproducts = new ArrayList<Product>();

    public static String prodname;
    public static int prodimg;
    public static String proddesc;
    public static int prodprice;

    public  void fillDetails(){
        prod.add(new Product("LIPSTICK",R.drawable.lp1,"Matte Red Lipstick. " +
                "A richly pigmented lipstick with a matte, velvety finish and easy one-stroke application. " +
                "The moisturising formula combines natural oils with conditioning vitamin E for soft and supple feel." +
                " 3.8 g. How to use: Apply on clean lips either alone",20));
        prod.add(new Product("LIPSTICK",R.drawable.lp2,"Pink Liquid Lipstick\n" +
                "MATTE LIP CREAM\n" +
                "Vivid liquid lipstick offering a super-matte, high-coverage finish. Glides on easily, leaving lips enveloped " +
                "in dramatic, velvety color. 0.30 fl. oz. Instructions: Apply on clean lips either alone or over lip primer",30));
        prod.add(new Product("LIPSTICK",R.drawable.lp3,"Lustrous Glass Shine Lipstick\n" +
                "Steal the show with a brilliant shine and lip colour that instantly melts onto lips with Super Lustrous Glass Shine Lipstick." +
                " Glass shine formula reflects light and provides flawless smooth, glass like shine. Glassy finish is as shiny as a lip gloss " +
                "with the ease of a lipstick & nourishment of a balm. Available in 12 glass shine colours.\n",35));
        prod.add(new Product("LIPSTICK",R.drawable.lp4,"Rimmel London\n" +
                "Lasting Finish Extreme Lipstick\n" +
                "Take everything to the extreme with Lasting Finish Extreme lipsticks from Rimmel London. When you want a lip colour that you can" +
                " trust to stay put hour after hour, Lasting Finish Extreme from Rimmel London is your go-to lipstick. You'll find that the creamy " +
                "formula glides on smoothly without dragging or skipping. It provides high impact colour in one stroke that feels lightweight and " +
                "fuses with lips upon application. Lips feel moisturised and comfortable all day long.\n",40));
        prod.add(new Product("LIPSTICK",R.drawable.lp5,"Quo Beauty\n" +
                "Lipstick\n" +
                "Big things come in small packages. This lipstick does double duty - pigments lips with a beautiful flush of colour, while keeping" +
                " it smooth with comfortable wear.\n",50));
        prod.add(new Product("LIPSTICK",R.drawable.lp6,"Avon Classic Red lipstick\n" +
                "Contents intact, though do not advise applying vintage lip colour\n" +
                "Cool case\n" +
                "Great condition",18));
        prod.add(new Product("EYESHADOW",R.drawable.es1,"Shadow Palette\n" +
                "Inspired by the brand's history with purple makeup, Urban Decay created Ultraviolet, the latest in the Naked eye shadow palette franchise." +
                " Unlike its predecessors, this one comes loaded with vibrant pink and purple hues, plus one color-shifting topper called Lucid.",49));
        prod.add(new Product("EYESHADOW",R.drawable.es2,"Pat McGrath Labs Mothership VIII Artistry Eye Shadow Palette Divine Rose II\n" +
                "In June, legendary makeup artist Pat McGrath partnered with Naomi Campbell to launch the Divine Rose II Shadow Palette, and " +
                "approval from Campbell is basically a guarantee of unbeatable quality. This palette features the first-ever \"triochrome\" — " +
                "a metallic shade that shifts between three different colors in the light —  to ever hit the market.",125));
        prod.add(new Product("EYESHADOW",R.drawable.es3,"Juvia's Place Warrior III Palette\n" +
                "Dip a finger into any Juvia's Place eye shadow palette and you'll instantly get why editors and influencers use them so much. " +
                "The brand's latest, the Warrior III Palette, delivers a spectrum of vivid mattes in its beloved, high-pigment formula. ",20));
        prod.add(new Product("EYESHADOW",R.drawable.es4,"Nars Orgasm Eye Shadow Quad\n" +
                "Nars translated its staple Orgasm blush into an Orgasm Eye Shadow Quad that's just as pretty — and universally flattering, " +
                "thanks to those metallic golds and peachy-pink shades.",52));
        prod.add(new Product("EYESHADOW",R.drawable.es5,"Uoma Beauty Allure Black Magic Color Palette\n" +
                "The way the powders in Uoma Beauty's Allure Black Magic Color Palette are loosely pressed make them intensely " +
                "pigmented yet easy to blend. What's more: This palette comes with the unique addition of Lady of Gold, a shade that looks" +
                " white in its pan but transforms into a light gold hue once applied. ",44));
        prod.add(new Product("EYELINER",R.drawable.el1,"BLack Liner" +
                "If you want an eyeliner that will stay put without fading, this Physicians Formula gel pencil is it." +
                " In our Lab’s test, 100% of women who tried it agreed that it didn’t fade during wear. One even wore it to the gym and o" +
                "nly noticed slight fading on her bottom lash line. It comes with a sharpener at the base, but some testers found it difficult " +
                "to use because the liner is so soft. ",15));
        prod.add(new Product("EYELINER",R.drawable.el2,"Purple Liner" +
                "The Urban Decay 24/7 Glide-On Eye Pencil glides on without tugging, sticks around without smearing, " +
                "and has a huge range of both wearable and fun colors. ",17));
        prod.add(new Product("EYELINER",R.drawable.el3,"WaterProof Black Liquid" +
                "If you love the drama of cateye liner, you'll love how easy it is to achieve with Stila's Stay All Day Waterproof Liquid Eyeliner.\n" +
                "Liquid eyeliner has a learning curve — there's no getting around it. ",24));
        prod.add(new Product("EYELINER",R.drawable.el4,"Brown Crayon Liner" +
                "If you crave the dramatic look of liquid eyeliner, but despair of ever mastering the small brush or marker format, you'll love the" +
                " ease of applying Marc Jacobs Beauty Highliner " +
                "Gel Eye Crayon Eyeliner. It's shaped like a traditional pencil liner and goes on just as easily. ",30));
        prod.add(new Product("EYELINER",R.drawable.el5,"Black LongLasting Liner " +
                "Create flawlessly clean lines with The Super Slim by Infallible. The long wear ultra-fine felt tip draws precise lines without " +
                "feathering or smudging. " +
                "In one stroke, create sleek and sophisticated eye looks that lasts up to 12 hours.",22));
        prod.add(new Product("NAIL POLISH",R.drawable.n1,"Essie was clearly  the best of the test. It received top scores from testers," +
                " experts, and consumers, and testers also raved about its high gloss value and commented on how shiny the polish remained throughout" +
                " its entire wear-time. ",40));
        prod.add(new Product("NAIL POLISH",R.drawable.n2,"We found that on average this budget-friendly polish lasted the longest of any " +
                "polish we tested, with a wear of almost six and a half days without a base or top coat. One tester exclaimed: “I am very hard on my" +
                " hands…planting, sports, pot scrubbing with my nails…The polish has stayed perfectly on my hands as if it were the first day.” ",
                38));
        prod.add(new Product("NAIL POLISH",R.drawable.n3," Get results that rival the salon's with this innovative polish/top coat duo," +
                " which doesn't require the usual light to cure. A separate lab test showed that this lacquer dried fast, chipped less, and lasted " +
                "longer than regular nail polish.",29));
        prod.add(new Product("NAIL POLISH",R.drawable.n4,"This OPI polish outshone the competition when it came to dry time. Its average" +
                " dry time was almost a minute and half faster than the next runner up, and our nail technician gave OPI a perfect 5 for coverage. ",32));
        prod.add(new Product("NAIL POLISH",R.drawable.n5," This CoverGirl polish received by far the highest scores for chip-resistance," +
                " and lasted more than 6 days without issue. On average, testers reported getting their first chip on day 4, and the polish lasted " +
                "for an average of six and 1/4 days.",44));
        prod.add(new Product("HAIR CLIPS",R.drawable.h1,"Color:\tMulticolor\n" +
                "Composition:\t100% Metal\n" +
                "Type:\tHair Clips\n" +
                "Range:\tBig Girls ",14));
        prod.add(new Product("HAIR CLIPS",R.drawable.h2," A great multi-purpose snap clip. Plain black metal, 1.75 Inches long. " +
                "They are perfect for keeping hair in place, as well as for holding kippahs or caps.",15));
        prod.add(new Product("HAIR CLIPS",R.drawable.h3," Hair fashion jaw clamp beauty accessory women ladies tortoise shell claw hair " +
                "clips with super strong solid spring for thick or fine, long and shorter hair. Perfect for creating easy hairstyles; partial quick updo" +
                " or bun or full updos, holding your hair securely and tightly in place without any disc",30));
        prod.add(new Product("HAIR CLIPS",R.drawable.h4,"We attach great importance to customer experience and striving for 100% customer" +
                " satisfaction.We have made the following efforts:\n" +
                "\n" +
                "1.For the sale of products, we are subject to stringent testing.\n" +
                "\n" +
                "2.If you have any questions before your purchase, you can always contact us, we will provide you with the fastest" +
                " and most satisfactory answer. ",18));
        prod.add(new Product("HAIR CLIPS",R.drawable.h5," There are 12 pieces in one set, included 12 different patterns, eye-catching, " +
                "cute and graceful look.\n" +
                "Easy to handle and take apart, suitable for no matter girls at school or ladies at work.\n" +
                "Beautiful decorations in your hair for holidays, travel, home or as an everyday look to dress things up, a good addition to woman's " +
                "or girl's hair accessories box.",22));
        prod.add(new Product("TIARA",R.drawable.t1,"This piece is Handmade of high quality clear Cubic Zircon in silver-plated metal setting. ",25));
        prod.add(new Product("TIARA",R.drawable.t2," Vintage gold diadem decorated with diamonds and sapphires.",20));
        prod.add(new Product("TIARA",R.drawable.t3," June Bloomy Women Rose Floral Crown Hair Wreath Leave Flower Headband with Adjustable Ribbon",30));
        prod.add(new Product("TIARA",R.drawable.t4,"The Hand Krities - Offering Blue, White Blue And White Flower Tiara ",22));
        prod.add(new Product("TIARA",R.drawable.t5," Floral crown, tiara style, made of diferent sizes paper flowers and berries with raw brass golden leaves.",32));
        prod.add(new Product("SKIN CARE",R.drawable.s1, "3-piece Clean & Clear Daily Skincare Essentials set helps cleanse skin, treat and prevent pimples and breakouts for clearer, " +
                "healthier-looking skin",45));
        prod.add(new Product("SKIN CARE",R.drawable.s2, "belif The True Cream Aqua Bomb | Moisturizer for Combination to Oily Skin | Face Cream, Hydration, Clean Beauty",60));
        prod.add(new Product("SKIN CARE",R.drawable.s3, "Face Roller Natural Jade Roller for Face - Gua Sha Scrapping - Aging Wrinkles,Puffiness Facial Skin Care Product Massager - " +
                "Premium Authentic Jade Stone (Jade Roller&Guasha Set)",39));
        prod.add(new Product("SKIN CARE",R.drawable.s4, "LED Face Mask Light Therapy | 7 Color Skin Rejuvenation Therapy LED Photon Mask Light Facial Skin Care Anti Aging Skin Tightening Wrinkles " +
                "Toning Mask Home Light Therapy Facial Care Mask",42));
        prod.add(new Product("SKIN CARE",R.drawable.s5, "acial Steamer, JOMARTO Nano Ionic Facial Steamer, Home Humidifier Personal Vaporizer, Portable Home Skin Spa Steamers," +
                " Warm Mist for Moisturizing and Blackheads Acne Skin Care, Ideal Gift",65));
        prod.add(new Product("HAIR CARE",R.drawable.hc1, "Pantene Shampoo & Conditioner + Rescue Shot Treatment, with Rose Water, Nutrient" +
                " Blends Miracle Moisture Boost, Sulfate Free",70));
        prod.add(new Product("HAIR CARE",R.drawable.hc2, "WOW Apple Cider Vinegar Shampoo & Hair Conditioner Set - (2 x 16.9 Fl Oz / 500mL)",75));
        prod.add(new Product("HAIR CARE",R.drawable.hc3, "Castor Oil (2oz) USDA Certified Organic, 100% Pure, Cold Pressed, Hexane Free by Kate Blanc.",50));
        prod.add(new Product("HAIR CARE",R.drawable.hc4, "Premium Collagen Pills with Vitamin C, E - Hydrolyzed Collagen Peptides, Supports Hair Growth.",65));
        prod.add(new Product("HAIR CARE",R.drawable.hc5, "Ionic Hair Straightener Brush, CNXUS MCH Ceramic Heating + LED Display + " +
                "Adjustable Temperatures + Anti Scald Hair Straightening Brush, Portable Frizz-Free Hair Care Silky Straight Heated Comb",49));


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products);

        spinner =findViewById(R.id.spproduct);
        listView = findViewById(R.id.lvproduct);

        fillDetails();

        ArrayAdapter arrayAdapter = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,prods);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(arrayAdapter);

        spinner.setOnItemSelectedListener(this);
        listView.setOnItemSelectedListener(this);
        listView.setOnItemClickListener(this);


        back3 = findViewById(R.id.btnback3);
        back3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(getApplicationContext(),HairmasterHome.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            if (adapterView.getId() == R.id.spproduct){
                selectedproducts.clear();
                String ab = prods[i];
                for (int j = 0; j<prod.size(); j++)
                    if (prod.get(j).getCats().equals(ab))
                        selectedproducts.add(prod.get(j));
                listView.setAdapter(new ProductAdapter(this,selectedproducts));
            }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        if (adapterView.getId() == R.id.lvproduct){
            prodname = selectedproducts.get(i).getCats();
            prodimg = selectedproducts.get(i).getImgprod();
            proddesc = selectedproducts.get(i).getDesc();
            prodprice = selectedproducts.get(i).getPri();
            Intent intent = new Intent(this,ProductDetail.class);
            startActivity(intent);
        }
    }
}