package com.example.Splendour;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class hmBookUs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hm_book_us);
    }
}