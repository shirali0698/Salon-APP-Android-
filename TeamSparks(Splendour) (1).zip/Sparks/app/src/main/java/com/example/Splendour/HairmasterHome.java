package com.example.Splendour;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.FrameLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class HairmasterHome extends AppCompatActivity {
private BottomNavigationView mMainNav;
private FrameLayout mMainFrame;

private HomeFragment homeFragment;
private ServiceFragement serviceFragement;
private ShoppingFragment shoppingFragment;
private BookingFragment bookingFragment;
private ProfileFragment profileFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hairmaster_home);

        mMainNav = findViewById(R.id.main_nav);
        mMainFrame = findViewById(R.id.main_frame);

        homeFragment = new HomeFragment();
        serviceFragement = new ServiceFragement();
        shoppingFragment= new ShoppingFragment();
        bookingFragment = new BookingFragment();
        profileFragment = new ProfileFragment();

        setFragment(homeFragment);

        mMainNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.home:
                        mMainNav.setItemBackgroundResource(R.color.colorAccent);
                        setFragment(homeFragment);
                        return true;

                    case R.id.service:
                        mMainNav.setItemBackgroundResource(R.color.colorAccent);
                        setFragment(serviceFragement);
                        return true;

                    case R.id.book:
                        mMainNav.setItemBackgroundResource(R.color.colorAccent);
                        setFragment(bookingFragment);
                        return true;

                    case R.id.shop:
                        mMainNav.setItemBackgroundResource(R.color.colorAccent);
                        setFragment(shoppingFragment);
                        return true;

                    case R.id.profile:
                        mMainNav.setItemBackgroundResource(R.color.colorAccent);
                        setFragment(profileFragment);
                        return true;

                    default:
                        return false;
                }
            }
        });

    }
    private void setFragment(Fragment fragment){
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.main_frame,fragment);
        fragmentTransaction.commit();
    }
}