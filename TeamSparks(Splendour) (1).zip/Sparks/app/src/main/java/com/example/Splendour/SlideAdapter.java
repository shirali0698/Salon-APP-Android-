package com.example.Splendour;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

public class SlideAdapter extends PagerAdapter {
    Context context;
    LayoutInflater layoutInflater;

    public SlideAdapter(Context context){
        this.context = context;
    }

    //Arrays
    public  int[]slide_images = {
            R.drawable.finalapplogo,
            R.drawable.booking,
            R.drawable.salon,
            R.drawable.shopping
    };
    public  String[] slide_heading = {
            "SPLENDOUR",
            "Salon",
            "Booking",
            "Shopping"
    };

    public  String[] slide_desc = {
            "Splendour is an Salon Appointment Booking App where you can book an appointment in advance with beauty professional.",
            "Splendour has multiple Salon so you can find the salon that is right for you.",
            "Booking Appointment is much easy. You can book Appointment 24/7 and you can also reschedule and cancel your appointment.",
            "Shopping includes beauty products and hair accessories which you can buy anytime. You can also read the description of the product"
    };

    @Override
    public int getCount() {
        return slide_heading.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == (RelativeLayout) object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        layoutInflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View view = layoutInflater.inflate(R.layout.slide_layout,container,false);

        ImageView slideImageView = (ImageView) view.findViewById(R.id.slide_image);
        TextView slideHeading = (TextView) view.findViewById(R.id.slide_heading);
        TextView slideDescription = (TextView) view.findViewById(R.id.slide_description);

        slideImageView.setImageResource(slide_images[position]);
        slideHeading.setText(slide_heading[position]);
        slideDescription.setText(slide_desc[position]);
        container.addView(view);

        return view ;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((RelativeLayout)object);
    }
}
