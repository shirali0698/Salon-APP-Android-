package com.example.Splendour;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

public class Services extends AppCompatActivity implements AdapterView.OnItemSelectedListener, AdapterView.OnItemClickListener {
    Spinner sp;
    ListView lv;
    Button back5;

    ArrayList<Service> cat =  new ArrayList<Service>();
    String categories[] ={"Facial","Haircut","Waxing","Manicure"};

    ArrayList<Service> slectedcategories = new ArrayList<Service>();
    public static String title;
    public static String se;
    public static int p;

    public void fillData(){
        cat.add(new Service("Haircut","Bob Cut",40));
        cat.add(new Service("Haircut","Blunt Cut",50));
        cat.add(new Service("Haircut","Straight Cut",30));
        cat.add(new Service("Haircut","V Shape Cut",25));
        cat.add(new Service("Haircut","Layered Cut",35));
        cat.add(new Service("Haircut","Feather Cut",55));
        cat.add(new Service("Haircut","Baby Cut",20));
        cat.add(new Service("Haircut","Long Layers",60));
        cat.add(new Service("Manicure","Basic Manicure",35));
        cat.add(new Service("Manicure","Acrylic Manicure",45));
        cat.add(new Service("Manicure","Gel Manicure",50));
        cat.add(new Service("Manicure","French Manicure",55));
        cat.add(new Service("Manicure","American Manicure",30));
        cat.add(new Service("Manicure","Mirror Manicure",40));
        cat.add(new Service("Manicure","Paraffin Manicure",60));
        cat.add(new Service("Waxing","Soft Wax",35));
        cat.add(new Service("Waxing","Hard Wax",50));
        cat.add(new Service("Waxing","Gel Wax",60));
        cat.add(new Service("Waxing","Cream Wax",65));
        cat.add(new Service("Waxing","Chocolate Wax",40));
        cat.add(new Service("Waxing","Sugar Wax",33));
        cat.add(new Service("Waxing","Fruit Wax",40));
        cat.add(new Service("Facial","Classic Facial",35));
        cat.add(new Service("Facial","Microcurrent Facial",45));
        cat.add(new Service("Facial","Acupunture Facial",65));
        cat.add(new Service("Facial","Brightening Facial",40));
        cat.add(new Service("Facial","LED Light Theraphy",62));


    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_services);

        sp = findViewById(R.id.spCategory);
        lv = findViewById(R.id.lvServices);

        fillData();

        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,categories);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(aa);

        sp.setOnItemSelectedListener(this);
        lv.setOnItemSelectedListener(this);
        lv.setOnItemClickListener(this);

        back5 = findViewById(R.id.btnback5);
        back5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),HairmasterHome.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            if(adapterView.getId() == R.id.spCategory){
                slectedcategories.clear();
                String c = categories[i];
                for (int j = 0; j < cat.size(); j++)
                    if (cat.get(j).getCategory().equals(c))
                        slectedcategories.add(cat.get(j));
                lv.setAdapter(new ListAdapter(this,slectedcategories));
            }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        if (adapterView.getId() == R.id.lvServices){
            title = slectedcategories.get(i).getCategory();
            se = slectedcategories.get(i).getService();
            p = slectedcategories.get(i).getPrice();
            Intent intent = new Intent(this,SelectSalon.class);
            startActivity(intent);
        }
    }
}