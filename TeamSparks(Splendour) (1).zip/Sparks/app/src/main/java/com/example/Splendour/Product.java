package com.example.Splendour;

public class Product {

    String  cats;
    int imgprod;
    String desc;
    int pri;

    public Product(String cats, int imgprod, String desc, int pri) {
        this.cats = cats;
        this.imgprod = imgprod;
        this.desc = desc;
        this.pri = pri;
    }

    public String getCats() {
        return cats;
    }

    public int getImgprod() {
        return imgprod;
    }

    public String getDesc() {
        return desc;
    }

    public int getPri() {
        return pri;
    }
}
